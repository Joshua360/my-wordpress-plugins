<?php

namespace Forminator\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}