<?php

class Forminator_Calculator_Symbol_Opening_Bracket extends Forminator_Calculator_Symbol_Abstract {

	/**
	 * @inheritdoc
	 */
	protected $identifiers = array( '(' );

}