<div class="forminator-integration-popup__header">

	<h3 id="forminator-integration-popup__title" class="sui-box-title sui-lg" style="overflow: initial; white-space: normal; text-overflow: initial;">
		<?php echo esc_html( sprintf( /* translators: ... */ __( '%1$s Added', 'forminator' ), 'Google Sheets' ) ); ?>
	</h3>

</div>

<p class="sui-description" style="text-align: center;"><?php esc_html_e( 'You can now go to your forms and assign them to this integration', 'forminator' ); ?></p>