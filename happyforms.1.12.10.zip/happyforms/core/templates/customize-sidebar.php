<script type="text/template" id="happyforms-sidebar-template">
	<div id="happyforms-sidebar-controls"></div>
</script>
