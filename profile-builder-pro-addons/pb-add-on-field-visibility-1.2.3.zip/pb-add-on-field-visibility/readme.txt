=== Profile Builder - Field Visibility Add-On ===

Contributors: cozmoslabs, iova.mihai
Donate link: http://www.cozmoslabs.com/wordpress-profile-builder/
Tags: registration, profile, user registration, custom field registration, customize profile, user fields, builder, profile builder, custom profile, user profile, custom user profile, user profile page, 
custom registration, custom registration form, custom registration page, extra user fields, registration page, user custom fields, user listing, user login, user registration form, front-end login, 
front-end register, front-end registration, frontend edit profile, edit profileregistration, customize profile, user fields, builder, profile builder, custom fields, avatar
Requires at least: 3.1
Tested up to: 5.4.2
Stable tag: 1.2.3
Reguires Profile Builder at least: 2.0.8


Extends the functionality of Profile Builder by allowing you to change visibility options for the extra fields


== Description ==

Profile Builder - Field Visibility Add-On

Extends the functionality of Profile Builder by allowing you to change visibility options for the extra fields

NOTE:

This plugin is compatible with Profile Builder version 2.0.8 or higher
	

== Installation ==

1. Upload the profile-builder-field-visibility folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress