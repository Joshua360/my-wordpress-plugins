=== Profile Builder - Edit Profile Approved by Admin ===

Contributors: cozmoslabs, madalin.ungureanu
Donate link: http://www.cozmoslabs.com/wordpress-profile-builder/
Requires at least: 3.1
Tested up to: 5.5.3
Stable tag: 1.0.8
Reguires Profile Builder at least: 2.9.2


Extends the functionality of Profile Builder by allowing administrators to approve edit profile changes by users


== Description ==

Profile Builder - Edit Profile Approved by Admin

Extends the functionality of Profile Builder by allowing administrators to approve edit profile changes by users

NOTE:

This plugin is compatible with Profile Builder version 2.9.2 or higher

== Installation ==

1. Upload the pb-add-on-edit-profile-approved-by-admin folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==
= 1.0.8 -
* Added compatibility with the new Simple Upload field

= 1.0.7 =
* Added the posibility to customize the emails in Email Customizer

= 1.0.6 =
* Add support for the 'Checkbox', 'Radio', 'Select (Multiple)', 'Select (Country)', 'Select (Timezone)' and 'Select (Currency)' fields

= 1.0.5 =
* Select and Select User Role are now supported

= 1.0.4 =
* Fixed compatibility issue with Divi Theme