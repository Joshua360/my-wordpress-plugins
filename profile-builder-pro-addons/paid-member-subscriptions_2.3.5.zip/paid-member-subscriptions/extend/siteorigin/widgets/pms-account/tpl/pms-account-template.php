<?php echo do_shortcode( '[pms-account show_tabs="'.$instance['show_tabs'].'"]'); ?>
