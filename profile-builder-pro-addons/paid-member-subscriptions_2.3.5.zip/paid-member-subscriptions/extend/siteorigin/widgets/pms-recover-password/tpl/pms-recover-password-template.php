<?php echo do_shortcode( '[pms-recover-password redirect_url="'.$instance['pms_reset_redirect_url'].'"]'); ?>
