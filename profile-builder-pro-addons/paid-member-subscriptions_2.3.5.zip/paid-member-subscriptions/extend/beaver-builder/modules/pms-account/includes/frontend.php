<?php echo do_shortcode( '[pms-account show_tabs="'.$settings->show_tabs.'"]' ); ?>
