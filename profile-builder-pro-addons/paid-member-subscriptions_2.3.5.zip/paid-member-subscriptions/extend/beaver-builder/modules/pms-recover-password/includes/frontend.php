<?php echo do_shortcode( '[pms-recover-password redirect_url="'.$settings->after_recovery_redirect_url.'"]' ); ?>
