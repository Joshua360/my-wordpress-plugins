=== Profile Builder - MailPoet Integration Add-On ===

Contributors: cozmoslabs, razvan.mo
Donate link: http://www.cozmoslabs.com/wordpress-profile-builder/
Tags: mailpoet, newsletter, newsletters, mailpoet newsletters, mailpoet integration, registration, profile, user registration, custom field registration, customize profile, user fields, builder, profile builder, custom profile, user profile, custom user profile, user profile page,
custom registration, custom registration form, custom registration page, extra user fields, registration page, user custom fields, user listing, user login, user registration form, front-end login,
front-end register, front-end registration, frontend edit profile, edit profile registration, customize profile, user fields, builder, profile builder, custom fields, avatar
Requires at least: 3.1
Tested up to: 4.9.4
Stable tag: 1.0.6
Requires Profile Builder at least: 2.1.0



== Description ==

Profile Builder - MailPoet Integration Add-On

Allow users to subscribe to MailPoet Newsletter Lists.


NOTE:

This plugin requires and is compatible with Profile Builder version 2.1.0 or higher

== Installation ==

1. Upload and install the zip file via the built in WordPress plugin installer.
2. Activate the plugin from the "Plugins" admin panel using the "Activate" link.
3. Install and activate MailPoet Newsletters plugin.
4. Go to Manage Fields tab under Profile Builder menu and you'll have access to MailPoet Subscribe field.

